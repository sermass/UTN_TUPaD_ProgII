package com.mycompany.ejercitaciontpuno;

public class EjercicioSeis {

    public static void main(String[] args) {
        System.out.println("Nombre: Juan Pérez \n" +
                           "Edad: 30 años \n" +
                           "Dirección: \"Calle Falsa 123\"");
    }
    
}
