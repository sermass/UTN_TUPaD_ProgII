/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.ejercitaciontpuno;

/**
 *
 * @author Lenovo
 */
public class HolaMundo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Esta instruccion va a imprimir el mensaje "¡Hola, Java!" al ejecutar el programa
        System.out.println("¡Hola, Java!");
    }
    
}
