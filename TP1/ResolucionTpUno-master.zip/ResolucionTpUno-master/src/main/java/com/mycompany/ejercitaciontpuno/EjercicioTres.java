package com.mycompany.ejercitaciontpuno;

public class EjercicioTres {
  
    public static void main(String[] args) {
        // Declarmos variables nombre, edad, altura, estudiante
        String nombre = "Jeronimo Cortez";
        int edad = 22;
        double altura = 1.83;
        boolean estudiante = false;
        
        // Imprimimos las variables delcaradas por consola
        System.out.println(nombre);
        System.out.println(edad);
        System.out.println(altura);
        System.out.println(estudiante);
        
    }
    
}
