package com.mycompany.ejercitaciontpuno;

public class EjercicioDiez {

    public static void main(String[] args) {
        int a = 5;         
        int b = 2; 
        int resultado = a / b; 
        System.out.println("Resultado: " + resultado); 
    
    }
    
}
