package com.mycompany.ejercitaciontpuno;

import java.util.Scanner;

public class EjercicioNueve {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); 
        System.out.println("Ingresa tu nombre: ");
        String nombre = scanner.nextLine(); // Linea corregida 
        System.out.println("Hola, " + nombre); 
    
} 
}
